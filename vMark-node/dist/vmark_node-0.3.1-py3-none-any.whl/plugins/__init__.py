# filepath: /home/xmas/GIT-PG/vMark-node/vMark-node/plugins/__init__.py
# This makes the plugins directory a proper Python package